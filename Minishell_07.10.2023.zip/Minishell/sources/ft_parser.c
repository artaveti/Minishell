
#include "lib_for_minishell.h"

void ft_parser(t_token_list **token_list, t_environment_list *envp_list)
{
    t_token_list *tmp;
    tmp = *token_list;

    while (tmp != NULL)
    {
        if (tmp->type == WORD)
            ft_change_dollar_sign(&tmp->value, envp_list);
        //else if (tmp-type == Q_DOUBLE)
        tmp = tmp->next;
    }
    return ;
}

// #include <unistd.h>
// #include <stdio.h>

// void ft_change(char *c)
// {
//   *c = 'W';
//   return ;
// }

// int main() {
//   char c;
  
//   c = 'H';
  
//   printf("%c\n", c);
//   ft_change(&c);
//   printf("%c\n", c);

//   return 0;
// }


//printf("MEMCMP:::%d\n", !ft_memcmp(splitted_dollar_sign[j],
//        tmp->name_and_value[0], ft_strlen(string) + 1));

                // while(splitted_dollar_sign[j] != NULL)
                // {
                //     printf("Before[J:%d]:%s\n", j, splitted_dollar_sign[j]);
                //     j++;
                // }


                // while(splitted_dollar_sign[j] != NULL)
                // {
                //     printf("After[J:%d]:%s\n", j, splitted_dollar_sign[j]);
                //     j++;
                // }



    // tmp = *envp_list;
    // while(tmp != NULL)
    // {   
    //         printf("I am here\n");
    //     j = 0;
    //     while (splitted_dollar_sign[j] != NULL)
    //     {
    //         str_len = ft_strlen(splitted_dollar_sign[j]);
    //         if (!ft_memcmp(splitted_dollar_sign[j], tmp->name_and_value[0], str_len + 1))
    //         {
    //             free(splitted_dollar_sign[j]);
    //             splitted_dollar_sign[j] = tmp->name_and_value[1];
    //         }
    //         else
    //         {
    //             free(splitted_dollar_sign[j]);
    //             splitted_dollar_sign[j] = "\0";
    //         }
    //     j++;
    //     }
    //     tmp = tmp->next;
    // }