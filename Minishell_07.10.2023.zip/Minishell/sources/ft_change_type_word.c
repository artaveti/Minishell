
#include "lib_for_minishell.h"

void ft_split_value_word(char ***splitted_dollar_sign, char **word)
{
    char *tmp;
    int i;

    i = 0;
    while(splitted_dollar_sign[0][i] != NULL)
    {
        tmp = *word;
        *word = ft_strjoin(*word, splitted_dollar_sign[0][i]);
        free(tmp);
        free(splitted_dollar_sign[0][i]);
        i++;
    }
    return ;
}

void ft_change_dollar_sign(char **string, t_environment_list *envp_list)
{
    int i;
    char *word;
    char **splitted_dollar_sign;

        i = 0;
        while (string[0][i] != '\0')
        {
            if (string[0][i] == '$')
            {
                word = (char *)malloc(sizeof(char) * (i + 1));
                word[i] = '\0';
                splitted_dollar_sign = ft_split(string[0], '$');
                ft_change_dollar_sign_in_splitted(splitted_dollar_sign, &envp_list);
                word = ft_memmove(word, string[0], i);
                ft_split_value_word(&splitted_dollar_sign, &word);
                free(splitted_dollar_sign);
                free(string[0]);
                string[0] = ft_strdup(word);
                free(word);
                break ;
            }
            i++;
        }
    return ;
}

                // j = 0;
                // while(splitted_dollar_sign[j] != NULL)
                // {
                //     tmp = word;
                //     word = ft_strjoin(word, splitted_dollar_sign[j]);
                //     free(tmp);
                //     free(splitted_dollar_sign[j]);
                //     j++;
                // }
