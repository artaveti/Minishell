
#include "lib_for_minishell.h"

int ft_change_dollar_sign_in_string(char **string, char **name_and_value)
{
    char *tmp_str;
    char *exit_status_str;

    if (ft_strchr("?0123456789", *string[0]))
    {
        tmp_str = ft_strdup(*string + 1);
        if (*string[0] == '?')
        {
            exit_status_str = ft_itoa(exit_status);
            free(*string);
            *string = ft_strjoin(exit_status_str, tmp_str);
            free(exit_status_str);
        }
        else if (*string[0] == '0')
        {
            free(*string);
            *string = ft_strjoin("minishell", tmp_str);
        }
        else
        {   
            free(*string);
            *string = ft_strdup(tmp_str);
        }
        free(tmp_str);
        return (1);
    }
    else if (!ft_memcmp(*string, name_and_value[0], ft_strlen(*string) + 1))
    {
        free(*string);
        *string = ft_strdup(name_and_value[1]);
        return (1);
    }
    return (0);
}

void ft_change_dollar_sign_in_splitted(char **splitted_dollar_sign,
        t_environment_list **envp_list)
{
    t_environment_list *tmp;
    int i;

    i = 0;
    while(splitted_dollar_sign[i] != NULL)
    {   
        tmp = *envp_list;
        while (tmp != NULL)
        {
            if(ft_change_dollar_sign_in_string(&splitted_dollar_sign[i], tmp->name_and_value))
                break ;
            tmp = tmp->next;
            if (tmp == NULL)
            {
                free(splitted_dollar_sign[i]);
                splitted_dollar_sign[i] = ft_strdup("");
            }
        }
        i++;
    }
    system("leaks minishell");
    return ;
}

                    // tmp_str = ft_strdup(splitted_dollar_sign[j] + 1);
                    // free(splitted_dollar_sign[j]);
                    // splitted_dollar_sign[j] = ft_strjoin("minishell", tmp_str);
                    // free(tmp_str);


                    // tmp_str = ft_strdup(splitted_dollar_sign[j] + 1);
                    // free(splitted_dollar_sign[j]);
                    // exit_status_str = ft_itoa(exit_status);
                    // splitted_dollar_sign[j] = ft_strjoin(exit_status_str, tmp_str);
                    // free(exit_status_str);
                    // free(tmp_str);


                    
                    // tmp_str = ft_strdup(splitted_dollar_sign[j] + 1);
                    // free(splitted_dollar_sign[j]);
                    // splitted_dollar_sign[j] = ft_strdup(tmp_str);
                    // free(tmp_str);


            // if (ft_strchr("0123456789?", splitted_dollar_sign[j][0]))
            // {
            //     if (splitted_dollar_sign[j][0] == '0')
            //         ft_change_dollar_sign_in_splitted_string(&splitted_dollar_sign[j], '0');
            //     else if (splitted_dollar_sign[j][0] == '?')
            //         ft_change_dollar_sign_in_splitted_string(&splitted_dollar_sign[j], '?');
            //     else 
            //         ft_change_dollar_sign_in_splitted_string(&splitted_dollar_sign[j], 'n');
            //     break ;
            // }



// void ft_change_dollar_sign_in_string(char **string, char c)
// {
//     char *tmp_str;
//     char *exit_status_str;

//     tmp_str = ft_strdup(*string + 1);
//     free(*string);
//     if (c == '0')
//         *string = ft_strjoin("minishell", tmp_str);
//     else if (c == '?')
//     {
//         exit_status_str = ft_itoa(exit_status);
//         *string = ft_strjoin(exit_status_str, tmp_str);
//         free(exit_status_str);
//     }
//     else
//         *string = ft_strdup(tmp_str);
//     free(tmp_str);
//     return ;
// }


        //size_t str_len;
        //str_len = ft_strlen(splitted_dollar_sign[j]);
            // else if (!ft_memcmp(splitted_dollar_sign[j], tmp->name_and_value[0], str_len + 1))
            // {
            //     free(splitted_dollar_sign[j]);
            //     splitted_dollar_sign[j] = ft_strdup(tmp->name_and_value[1]);
            //     break;
            // }