
#include "lib_for_minishell.h"

void ft_change_dollar_sign(char **string, t_environment_list **envp_list)
{
    t_environment_list *tmp;
    // size_t str_len; 
    
    // str_len = ft_strlen(string);
    tmp = *envp_list;
    // while (tmp != NULL)
    // {
        //printf("MEMCMP:::%d\n", !ft_memcmp(string, tmp->name_and_value[0], ft_strlen(string) + 1));
        // if (!ft_memcmp(string, tmp->name_and_value[0], str_len + 1))
        // {
            //printf("%s\n", string);
            free(*string);
            *string = "Hello";
            //string = (char *)malloc(sizeof(char) * (ft_strlen(tmp->name_and_value[1]) + 1));
            //string = tmp->name_and_value[1];
            // string[0] = tmp->name_and_value[1][0];
            // string[1] = tmp->name_and_value[1][1];
            // string[2] = tmp->name_and_value[1][2];
            // printf("%p\n", &string[0]);
            // printf("%p\n", &tmp->name_and_value[1][0]);
           // break;
        system("leaks minishell");
       // }
       // tmp = tmp->next;
    //}
    printf("%s\n", *string);
    //ft_list_iter_printf_for_environment(*envp_list, printf);
    return ;
}

void ft_is_dollar_sign(t_token_list *token_list, t_environment_list *envp_list)
{
    int i;
    int j;
    char **splitted_dollar_sign;

    if (token_list->type == WORD)
    {
        i = 0;
        while (token_list->value[i] != '\0')
        {
            if (token_list->value[i] == '$')
            {
                splitted_dollar_sign = ft_split(&token_list->value[i], '$');
                //printf("I:::%d\n", i);
                j = 0;
                while(splitted_dollar_sign[j] != NULL)
                {   
                    printf("[J:::%d]%s\n", j, splitted_dollar_sign[j]);
                    ft_change_dollar_sign(&splitted_dollar_sign[j], &envp_list);
                    printf("{J:::%d}%s\n", j, splitted_dollar_sign[j]);
                    j++;
                }
                break ;
            }
            i++;
        }
    }
    return ;
}

void ft_parser(t_token_list **token_list, t_environment_list *envp_list)
{
    t_token_list *tmp;
    tmp = *token_list;

    while (tmp != NULL)
    {
        ft_is_dollar_sign(tmp, envp_list);
        tmp = tmp->next;
    }
    return ;
}

// #include <unistd.h>
// #include <stdio.h>

// void ft_change(char *c)
// {
//   *c = 'W';
//   return ;
// }

// int main() {
//   char c;
  
//   c = 'H';
  
//   printf("%c\n", c);
//   ft_change(&c);
//   printf("%c\n", c);

//   return 0;
// }